import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Calculadora {

    private double total1 = 0.0;
    private double total2 = 0.0;
    private char operador;
    private JPanel Calculadora;
    private JTextField textField1;
    private JButton BClear;
    private JButton BMenos;
    private JButton BMult;
    private JButton BDiv;
    private JButton BMais;
    private JButton BIgual;
    private JButton BZero;
    private JButton BUm;
    private JButton BDois;
    private JButton BTres;
    private JButton BQuatro;
    private JButton BCinco;
    private JButton BSeis;
    private JButton BSete;
    private JButton BOito;
    private JButton BNove;
    private JButton BPonto;

    private void getOperador(String Texto){
        operador=Texto.charAt(0);
        total1=total1+Double.parseDouble((textField1.getText()));
        textField1.setText("");
    }

    public Calculadora() {

        BZero.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String BZeroTexto = textField1.getText() + BZero.getText();
                textField1.setText(BZeroTexto);
            }
        });

        BUm.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String BUmTexto = textField1.getText() + BUm.getText();
                textField1.setText(BUmTexto);
            }
        });

        BDois.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String BDoisTexto = textField1.getText() + BDois.getText();
                textField1.setText(BDoisTexto);
            }
        });

        BTres.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String BTresTexto = textField1.getText() + BTres.getText();
                textField1.setText(BTresTexto);
            }
        });

        BQuatro.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String BQuatroTexto = textField1.getText() + BQuatro.getText();
                textField1.setText(BQuatroTexto);
            }
        });

        BCinco.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String BCincoTexto = textField1.getText() + BCinco.getText();
                textField1.setText(BCincoTexto);
            }
        });

        BSeis.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String BSeisTexto = textField1.getText() + BSeis.getText();
                textField1.setText(BSeisTexto);
            }
        });

        BSete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String BSeteTexto = textField1.getText() + BSete.getText();
                textField1.setText(BSeteTexto);
            }
        });

        BOito.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String BOitoTexto = textField1.getText() + BOito.getText();
                textField1.setText(BOitoTexto);
            }
        });

        BNove.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String BNoveTexto = textField1.getText() + BNove.getText();
                textField1.setText(BNoveTexto);
            }
        });
        BMais.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String Texto = BMais.getText();
                getOperador(Texto);
            }
        });
        BIgual.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switch (operador){
                    case('+'):
                        total2=total1+Double.parseDouble(textField1.getText());
                        break;
                    case('-'):
                        total2=total1-Double.parseDouble(textField1.getText());
                        break;
                    case('/'):
                        total2=total1/Double.parseDouble(textField1.getText());
                        break;
                    case('X'):
                        total2=total1*Double.parseDouble(textField1.getText());
                        break;
                }
                textField1.setText(Double.toString(total2));
                total1 = 0;
            }
        });
        BClear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                total2=0;
                textField1.setText("");
            }
        });
        BPonto.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(textField1.getText().equals((""))){
                    textField1.setText("0.");
                }
                else if(textField1.getText().contains(".")){
                    BPonto.setEnabled(false);
                }
                else{
                    String BPontoTexto = textField1.getText() + BPonto.getText();
                    textField1.setText(BPontoTexto);
                }
                BPonto.setEnabled(true);
            }
        });
        BMenos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String Texto = BMenos.getText();
                getOperador(Texto);
            }
        });
        BDiv.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String Texto = BDiv.getText();
                getOperador(Texto);
            }
        });
        BMult.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String Texto = BMult.getText();
                getOperador(Texto);
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Calculadora");
        frame.setContentPane(new Calculadora().Calculadora);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
