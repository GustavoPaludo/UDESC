import java.util.Scanner;

public class Main {
    public static void main (String [] args){
        System.out.println("Digite uma medida:");
        Scanner scan = new Scanner(System.in);
        double medida = scan.nextDouble();
        Quadrado quadrado = new Quadrado(medida);
        Cubo cubo = new Cubo(medida);
        System.out.println("Area do quadrado de lado "+quadrado.getMedidaLados() +" : "+quadrado.getArea());
        System.out.println("Area do cubo de lado "+cubo.getMedidaLados() +" : "+cubo.getArea());
    }
}
