public class Quadrado {
    private double medidaLados;
    public Quadrado (Double medidaLados){
        this.medidaLados=medidaLados;
    }
    public double getArea(){
        return medidaLados*medidaLados;
    }
    public double getMedidaLados(){
        return medidaLados;
    }

}
