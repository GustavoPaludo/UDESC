public class Pessoa {
    private String  nome;
    private String  numero;

    public Pessoa(String nome, String numero) {
        this.nome  = nome;
        this.numero   = numero;
    }

    protected String getNome() {
        return nome;
    }
    protected String getNumero() {
        return numero;
    }

}
