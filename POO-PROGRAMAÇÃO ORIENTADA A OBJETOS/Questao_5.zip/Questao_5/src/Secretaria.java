import java.util.Scanner;

public class Secretaria {

    private final RegistroAlunos registroAlunos = new RegistroAlunos();
    private final RegistroProfessores registroProfessores = new RegistroProfessores();
    public Secretaria(){

    }
    public void realizeOpcao(int opcao) {
        switch(opcao){
            case 1:
                adicionarAluno();
                break;
            case 2:
                listarAlunos();
                break;
            case 3:
                adicionarProfessor();
                break;
            case 4:
                listarProfessores();
                break;
        }
    }

    private void listarAlunos(){
        int totalAlunos = registroAlunos.getQuantidadeAlunos();
        for(int i=0;i<totalAlunos;i++){
            System.out.println("Aluno numero "+(i+1) +" : \n");
            System.out.println("Nome: "+registroAlunos.getAluno(i).toStringNome());
            System.out.println("Numero: "+registroAlunos.getAluno(i).toStringNumero());
            System.out.println("Curso: "+registroAlunos.getAluno(i).toStringCurso());
            System.out.println("");
        }
    }

    private void adicionarAluno(){
        Scanner scan = new Scanner(System.in);
        System.out.println("Digite o nome do aluno: ");
        String nome = scan.nextLine();
        System.out.println("Digite o telefone do aluno: ");
        String numero = scan.nextLine();
        System.out.println("Digite o curso do aluno: ");
        String curso = scan.nextLine();

        Alunos novoAluno = new Alunos(nome,numero,curso);
        registroAlunos.adicionarAluno(novoAluno);
    }

    private void listarProfessores(){
        int totalProfessores = registroProfessores.getQuantidadeProfessores();
        for(int i=0;i<totalProfessores;i++){
            System.out.println("Professor numero "+(i+1) +" : \n");
            System.out.println("Nome: "+registroProfessores.getProfessor(i).toStringNome());
            System.out.println("Numero: "+registroProfessores.getProfessor(i).toStringNumero());
            System.out.println("Materias: "+registroProfessores.getProfessor(i).toStringMaterias());
            System.out.println("");
        }
    }

    private void adicionarProfessor(){
        Scanner scan = new Scanner(System.in);
        System.out.println("Digite o nome do professor: ");
        String nome = scan.nextLine();
        System.out.println("Digite o telefone do professor: ");
        String numero = scan.nextLine();
        System.out.println("Digite as materias do professor: ");
        String materias = scan.nextLine();

        Professores novoProfessor = new Professores(nome,numero,materias);
        registroProfessores.adicionarProfessor(novoProfessor);
    }
}
