public class Main {
    public static void main(String[] args){
        Menu menu = new Menu();
        Secretaria secretaria = new Secretaria();

        int opcao = -1;

        do{
            opcao = menu.opcoes();
            secretaria.realizeOpcao(opcao);
        }while(opcao !=5);
    }
}
