import java.util.Scanner;
public class Menu {
    public Menu() {

    }
    public int opcoes() {
        int opcaoSelecionada = -1;

        System.out.println("1. Adicionar Aluno");
        System.out.println("2. Listar Alunos");
        System.out.println("3. Adicionar Professor");
        System.out.println("4. Listar Professores");
        System.out.println("5. Sair");

        System.out.println("Escolha uma opcao:");
        Scanner scanner = new Scanner(System.in);
        opcaoSelecionada = scanner.nextInt();

        return opcaoSelecionada;
    }
}

