public class Professores extends Pessoa {
    private String materias ;

    public Professores(String nome, String numero, String materias){
        super(nome,numero);
        this.materias = materias;
    }
    public String toStringNome(){
        return super.getNome();
    }
    public String toStringNumero(){
        return super.getNumero();
    }
    public String toStringMaterias(){
        return materias;
    }
}
