public class RegistroAlunos {
    private final Alunos [] listaAlunos;
    private static final int totalAlunos = 50;
    private int quantidadeAlunos;


    public RegistroAlunos(){
        listaAlunos = new Alunos[totalAlunos];
        quantidadeAlunos=0;
    }
    public void adicionarAluno(Alunos novoAluno){
        if(quantidadeAlunos<totalAlunos){
            listaAlunos[quantidadeAlunos]=novoAluno;
            quantidadeAlunos++;
        }
    }
    public Alunos getAluno(int i){
        if(i<totalAlunos){
            return listaAlunos[i];
        }
        return null;
    }


    public int getQuantidadeAlunos(){
        return quantidadeAlunos;
    }
}
