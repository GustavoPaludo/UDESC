public class Alunos extends Pessoa{
    private String curso;

    public Alunos(String nome, String numero, String curso){
        super(nome,numero);
        this.curso = curso;
    }
    public String toStringNome(){
        return super.getNome();
    }
    public String toStringNumero(){
        return super.getNumero();
    }
    public String toStringCurso(){
        return curso;
    }
}
