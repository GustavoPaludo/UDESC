public class RegistroProfessores {
    private final Professores [] listaProfessores;
    private static final int totalProfessores = 50;
    private int quantidadeProfessores;


    public RegistroProfessores(){
        listaProfessores = new Professores[totalProfessores];
        quantidadeProfessores=0;
    }
    public void adicionarProfessor(Professores novoProfessor){
        if(quantidadeProfessores<totalProfessores){
            listaProfessores[quantidadeProfessores]=novoProfessor;
            quantidadeProfessores++;
        }
    }
    public Professores getProfessor(int i){
        if(i<totalProfessores){
            return listaProfessores[i];
        }
        return null;
    }


    public int getQuantidadeProfessores(){
        return quantidadeProfessores;
    }
}
