public class Impressor {
    public void imprimir(String palavra) {
        System.out.println("----> "+palavra);
    }
}
