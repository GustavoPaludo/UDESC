import java.util.Scanner;

public class Leitor {
    public String lerPalavra() {
        Scanner scan = new Scanner(System.in);
        return scan.nextLine();
    }

    public String lerOpcao(String ...opcoes) {
        System.out.println("Escolha uma opçao (Consoantes, vogais):");
        for(String s : opcoes){
            System.out.println(s);
        }
        Scanner scan = new Scanner(System.in);
        return scan.nextLine();
    }
}
