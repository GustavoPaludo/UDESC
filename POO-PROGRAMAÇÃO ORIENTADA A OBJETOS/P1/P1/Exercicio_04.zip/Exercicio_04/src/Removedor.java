public class Removedor {
    public String removerConsoante(String palavra) {
        palavra = palavra.replaceAll("[qwrtypsdfghjklçzxcvbnm]","");
        palavra = palavra.replaceAll("[QWRTYPSDFGHJKLÇZXCVBNM]","");
        return palavra;
    }

    public String removerVogal(String palavra) {
        palavra = palavra.replaceAll("[aeiou]","");
        palavra = palavra.replaceAll("[AEIOU]","");
        return palavra;
    }
}
