public class Main {
    public static void main(String[] args){
        Leitor leitor = new Leitor();
        Removedor removedor = new Removedor();
        Impressor impressor = new Impressor();
        System.out.println("Digite uma palavra: ");
        String palavra =leitor.lerPalavra();
        String opcao = leitor.lerOpcao("1","2");
        if(opcao.equalsIgnoreCase("1")) {
            palavra = removedor.removerConsoante(palavra);
        }
        else{
            palavra = removedor.removerVogal(palavra);
        }
        impressor.imprimir(palavra);
    }
}
