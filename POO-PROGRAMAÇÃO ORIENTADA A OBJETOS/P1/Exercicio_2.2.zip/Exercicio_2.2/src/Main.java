public class Main {
    public static void main(String[] args) {
        String temp = "ROMA";
        temp = Inversor.inverterString(temp);
        System.out.println(" "+temp);
    }
}
